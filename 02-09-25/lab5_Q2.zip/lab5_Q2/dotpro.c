#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "libs/matfun.h"

int main() {
    int n = 5;

    double **v1 = loadMat("a.dat", n, 1);
    double **v2 = loadMat("b.dat", n, 1);

    printf("Values from a.dat:\n");
    printMat(v1, n, 1);

    printf("Values from b.dat:\n");
    printMat(v2, n, 1);

    double dot_product = Matdot(v1, v2, n);
    printf("The dot product is %.1f.\n", dot_product);

    freeMat(v1, n);
    freeMat(v2, n);

    return 0;
}

