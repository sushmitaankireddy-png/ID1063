import numpy as np

v1 = np.loadtxt('a.dat')
v2 = np.loadtxt('b.dat')

print("Values from a.dat:", v1)
print("Values from b.dat:", v2)

dot_product = np.dot(v1, v2)
print(f"The dot product is {dot_product}.")

